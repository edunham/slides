#!/usr/bin/env sh
./servo -w -b --pref dom.mozbrowser.enabled --pref dom.forcetouch.enabled --pref shell.builtin-key-shortcuts.enabled=false ./build/browserhtml-5c846c4e388d17ec/out/index.html